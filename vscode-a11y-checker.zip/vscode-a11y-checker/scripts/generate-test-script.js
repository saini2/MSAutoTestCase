#!/usr/bin/env node

const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const codeLibraries = ["React + TypeScript", "ASP.NET", "Vue + JavaScript", "Node.js + TypeScript"];
const fileTypes = {
  "React + TypeScript": ".tsx",
  "ASP.NET": ".cs",
  "Vue + JavaScript": ".vue",
  "Node.js + TypeScript": ".ts"
};
const testingLibraries = {
  "React + TypeScript": "React Testing Library and Jest",
  "ASP.NET": "NUnit",
  "Vue + JavaScript": "Jest",
  "Node.js + TypeScript": "Mocha + Chai"
};

function askQuestion(question, choices) {
  return new Promise((resolve) => {
    console.log(`\n${question}`);
    choices.forEach((choice, index) => console.log(`${index + 1}. ${choice}`));
    rl.question("Enter your choice (number): ", (answer) => {
      const index = parseInt(answer) - 1;
      resolve(choices[index]);
    });
  });
}

async function generatePrompt() {
  const testType = await askQuestion("Do you want to write test cases from scratch or add missing test cases?", [
    "Scratch",
    "Missing"
  ]);

  const scope = await askQuestion("What kind of tests do you want to generate?", [
    "Unit Tests",
    "Integration Tests"
  ]);

  let prompt = "";

  if (scope === "Unit Tests") {
    const tech = await askQuestion("Select the technology stack:", codeLibraries);
    const fileExt = fileTypes[tech];
    const lib = testingLibraries[tech];

    if (testType === "Scratch") {
      prompt = `For each ${fileExt} component in this ${tech} project, generate a corresponding .test${fileExt} file using ${lib}. The test should include:

1. A render test to verify that the component renders without crashing.
2. Tests for each significant prop or interaction (e.g., button clicks, form submissions).
3. Coverage of conditional rendering paths, if applicable.
4. Use appropriate methods from ${lib} for rendering, querying, firing events, and simulating user actions.
5. Add all necessary files, if required, like tsconfig.json, jsconfig.node.json, jestconfig.json, setupTests.ts.
6. Take permission and install all necessary packages.

Follow best practices for test structure and naming. Place each generated test file next to its corresponding ${fileExt} file with the name format: [ComponentName].test${fileExt}.`;
    } else {
      prompt = `Identify any missing unit test scenarios in this ${tech} project where some .test${fileExt} files already exist for each component. For any components or functionalities that do not have test coverage (or have incomplete coverage):

Prompt me for permission if new dependencies, files, or modifications to the file structure are necessary (e.g., adding tsconfig.json, jsconfig.node.json, jestconfig.json, or setupTests.ts).

Generate new test blocks or new .test${fileExt} files for each missing scenario, following the format [ComponentName].test${fileExt}.

Each test should cover:
- Basic render tests (ensuring the component renders without crashing)
- Significant props or interactions (e.g., button clicks, form submissions, prop changes)
- Conditional rendering (if applicable)
- Usage of appropriate methods from ${lib}

Explain the logic behind each added test and why it was missing previously.

Confirm or prompt to install any additional necessary packages and dependencies.

Instruct how to run these updated tests (e.g., using npm test or similar command).`;
    }
  } else if (scope === "Integration Tests") {
    if (testType === "Scratch") {
      prompt = `Create new integration tests from scratch using Playwright for this project.

Set up the entire Playwright testing environment (install Playwright, configure scripts in package.json, etc.).

Prompt me for permission before installing or modifying any dependencies.

Generate any necessary configuration files (e.g., playwright.config.ts) with recommended best practices (e.g., base URL, test directory structure).

Write a sample integration test (e.g., Playwright.spec.ts) that demonstrates:
- Navigating to a page/route in the application.
- Clicking on an element or filling out a form.
- Making assertions about the rendered output.

Comment each step of the test to explain the logic and best practices.

Ensure all final instructions are clear on how to run the tests from the command line.

Follow best practices for structuring Playwright tests and use a clean, descriptive file-naming convention for integration tests (e.g., SomeFeature.integration.spec.ts).`;
    } else {
      prompt = `Identify missing integration test scenarios in this existing Playwright test suite. For any functionalities or user flows that do not have test coverage:

Prompt me for permission if new dependencies or modifications to file structure are needed.

Generate new test blocks or new test files (e.g., SomeFeature.integration.spec.ts) to cover all missing scenarios.

Each test should demonstrate:
- Navigation to the relevant page or route
- User interactions (clicking, typing, form submissions)
- Assertions (validating UI changes, confirmations, or resulting data)

Comment each test thoroughly to explain how it fits into the overall integration test flow.

Explain how to run these new tests alongside the existing ones.

Follow best practices for structuring Playwright tests and integrate them seamlessly into the existing test configuration (e.g., playwright.config.ts).`;
    }
  }

  console.log("\n📄 Generated Prompt:\n");
  console.log(prompt.trim());
  rl.close();
}

generatePrompt();
