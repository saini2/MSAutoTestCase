const axios = require('axios');

// Step 1: Classify the prompt based on intent and technology
function classifyPrompt(prompt) {
  const jsPromptKeywords = ['tsx', 'react', 'jest', 'testing-library', 'render', 'unit test'];
  const integrationKeywords = ['playwright', 'integration', 'navigate', 'fill', 'spec.ts'];

  const lowerPrompt = prompt.toLowerCase();
  const isJsPrompt = jsPromptKeywords.some(k => lowerPrompt.includes(k));
  const isIntegrationPrompt = integrationKeywords.some(k => lowerPrompt.includes(k));

  if (isJsPrompt && !isIntegrationPrompt) return 'unit-react';
  if (isIntegrationPrompt && !isJsPrompt) return 'integration-playwright';
  if (isJsPrompt && isIntegrationPrompt) return 'fullstack-test'; // fallback if unclear
  return 'other';
}

// Step 2: Decide which Copilot model to use
function getModelByPromptType(type) {
  switch (type) {
    case 'unit-react':
      return 'sonnet-3.7';
    case 'integration-playwright':
        return 'sonnet-3.7';
    case 'fullstack-test':
      return 'gpt-4o';
    default:
      return 'gpt-4o';
  }
}

// Step 3: Construct a structured Copilot API payload
function buildPayload(prompt, model) {
  return {
    model,
    agent_mode: true,
    messages: [
      {
        role: 'system',
        content: 'You are a software testing expert capable of generating test scaffolds, suggesting packages, and producing high-quality, annotated test files.'
      },
      {
        role: 'user',
        content: prompt
      }
    ]
  };
}

// Step 4: Send prompt to GitHub Copilot Agent API
async function sendToCopilot(prompt) {
  const promptType = classifyPrompt(prompt);
  const model = getModelByPromptType(promptType);
  const payload = buildPayload(prompt, model);

  try {
    const response = await axios.post('https://api.githubcopilot.com/agent-mode/chat/completions', payload, {
      headers: {
        'Authorization': `Bearer YOUR_COPILOT_TOKEN`,
        'Content-Type': 'application/json'
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error sending to Copilot API:', error.response?.data || error.message);
    return null;
  }
}

// Step 5: Trigger test
(async () => {
  const testPrompts = [
    // Prompt 1
    `For each .tsx component in this React project, generate a corresponding .test.tsx file...`,
    // Prompt 2
    `Create new integration tests from scratch using Playwright for this project...`,
    // Prompt 3
    `Identify any missing unit test scenarios in this React project...`,
    // Prompt 4
    `Identify missing integration test scenarios in this existing Playwright test suite...`
  ];

  for (const prompt of testPrompts) {
    const result = await sendToCopilot(prompt);
    console.log('Result for prompt:', prompt.slice(0, 80) + '...');
    console.dir(result, { depth: 4 });
  }
})();
