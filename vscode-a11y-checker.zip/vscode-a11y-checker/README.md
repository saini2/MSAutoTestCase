# VSCode A11y Checker

VSCode A11y Checker is a Visual Studio Code extension that helps generate automated test case instructions for various tech stacks (React, .NET, Node.js, etc.). It provides a friendly command to run your test generation script based on selected stack preferences.

## Features

- Runs a test generation script via command palette
- Supports multiple tech stacks and testing libraries
- Interactive CLI prompt integration inside the editor
- Works on any open project workspace
- Easy to configure and extend

## Requirements

- Node.js must be installed
- No other dependencies required; the script will ask for permission before installing any

## Extension Settings

This extension does not contribute any settings yet.

## Known Issues

- Interactive terminal might not render perfectly on all terminals.
- Script might require manual permission to run dependencies.

## Release Notes

### 1.0.0

- Initial release of `vscode-a11y-checker`
- Integrated support for test generation via CLI
- Works with multiple frameworks

---

Enjoy writing accessible and testable code faster with A11y Checker!
