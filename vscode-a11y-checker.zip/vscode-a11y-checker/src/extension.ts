import * as vscode from 'vscode';
import * as cp from 'child_process';
import * as path from 'path';

export function activate(context: vscode.ExtensionContext) {
  const disposable = vscode.commands.registerCommand('extension.generateTests', () => {
    const scriptPath = path.join(context.extensionPath, 'scripts', 'generate-test-script.js');

    const terminal = vscode.window.createTerminal({
      name: 'Generate Test Cases',
    });

    terminal.show();
    terminal.sendText(`node "${scriptPath}"`);
  });

  context.subscriptions.push(disposable);
}

export function deactivate() {}
